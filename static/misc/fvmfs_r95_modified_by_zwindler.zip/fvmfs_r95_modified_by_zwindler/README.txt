WARNING! This is NOT an official version. 

The version r95 of the VMFS driver provided by http://www.fluidops.com/ (source on 
http://code.google.com/p/vmfs/) as been modified by zwindler (http://zwindler.free.fr). 
Appart from the slight addition I made, everything else belongs to fluid Operations.

This one may have bugs (from fluidops, from me, or from an incompatibility between my 
code and the source). It may not be up to date.

Please use this tool with EXTREME caution. If you do not need the feature that I 
included (recursive filecopy trhough CLI, the "cp -r" equivalent, missing in the 
official source), DON'T use this one (or be prepared to suffer the consequences).

Because of the GPL licence of the original source code from fluidops, you may not use 
this tool for commercial purposes. Please read the terms of the licence on fluidops 
website.

